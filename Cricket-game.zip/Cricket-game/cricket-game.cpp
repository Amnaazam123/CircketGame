#include<iostream>
#include<string>
#include<cstdlib>
#include<iomanip>
void tossing();
void bowling(int, int);
using namespace std;
int main()
{
	tossing();
	return 0;
}
void show(int players, string name[], int score[])
{
	cout << endl << "********************* Your team score ************************" << endl;
	for (int i = 0; i < players; i++)
	{
		cout << setw(20);
		cout.setf(ios::left);
		cout << name[i];
		cout << score[i] << endl;
	}
}
void batting(int overs, int n_players, int plyr, string name[])
{
	int flag = 0;
	int score[20] = { 0 };
	int peak1 = 0, ovr = 0;
	string hint1, choice;
	string bat1, bat2;
	for (int i = 0; i < n_players; i++)
	{
		cout << "Player " << i + 1 << ": ";
		cin >> name[i];
	}
	if (n_players > 2)             //if players are greater than 2 then choose batsman.
	{
		cout << "Enter the names of your players which you want for batting as openers:" << endl;
		do {
			cout << "batsman 1:";
			cin >> bat1;
			cout << "batsman 2:";
			cin >> bat2;
			flag = 0;
			for (int i = 0; i < n_players; i++)                 //nmaes should be that entered above.
			{
				if (name[i] == bat1 || name[i] == bat2)
					flag++;
			}
			if (flag < 2)
				cout << "enter any name in the above entered names of batsman" << endl;
		} while (flag < 2);
		for (int i = 0; i < n_players; i++)                       //striker
			if (bat1 == name[i] || bat2 == name[i])
				cout << name[i] << " is active " << endl;
		cout << "which one is stricker..." << bat1 << " or " << bat2 << " ?";
		cin >> choice;
		cout << "so " << choice << " is stricker and other one is non striker";
	}
	if (choice == bat1)                     //hint1 is non_stricker
		hint1 = bat2;
	else
		hint1 = bat1;
	for (int i = 0; i < n_players; i++)
	{
		if (name[i] == bat1 && choice == bat1)
			peak1 = i;
		if (name[i] == bat2 && choice == bat2)
			peak1 = i;
	}
	show(plyr, name, score);
	cout << "Keep in mind if you select greater numbers for score there is a risk of wicket...." << endl;
	cout << "**********BEST OF LUCK********** " << endl;
	cout << "what do you want? sixer? four? dot-ball? run?" << endl;
	int count_ball = 0;
	char option;
	int i = 0, j = 0;
	string store1, store2;
	do {
		cout << endl << endl << "Enter s for six" << endl;
		cout << "Enter f for four" << endl;
		cout << "Enter r for run" << endl;
		cout << "Enter d for dot_ball" << endl;
		cin >> option;
		if (i % 3 == 0 && i != 0 && option != 'd')
		{
			cout << "Oh!...." << choice << " has been out" << endl;
			n_players--;
			store2 = choice;
			count_ball++;
			cout << "number of players remaing : " << n_players << endl;
			string new_player;
			do {
				cout << endl << "New batsman: ";
				cin >> new_player;
				if (new_player == choice)
					cout << "this player has been out" << endl;
			} while (new_player == choice);
			choice = new_player;
			for (int c = 0; c < plyr; c++)
			{
				if (name[c] == choice)
				{
					peak1 = c;
					break;
				}
			}
		}
		else
		{
			if (option == 's')
			{
				cout << "Congrats! there was sixer. " << endl;
				int lp = 0;
				for (int z = peak1; lp < 1; lp++)
					score[z] += 6;
				count_ball += 1;
			}
			if (option == 'd')
			{
				cout << "NO any score ....it is dot ball. " << endl;
				int lp = 0;
				for (int z = peak1; lp < 1; lp++)
					score[z] += 0;
				count_ball += 1;
			}
			if (option == 'f')
			{
				cout << "Congrats! there was four." << endl;
				int lp = 0;
				for (int z = peak1; lp < 1; lp++)
					score[z] += 4;
				count_ball += 1;
			}
			if (option == 'r')
			{
				if (j % 5 == 0 && j != 0)
				{
					cout << "Oh!...." << choice << " has been out" << endl;
					store1 = choice;
					n_players--;
					count_ball++;
					cout << "number of players remaing : " << n_players;
					string new_player;
					do {
						cout << endl << "New batsman: ";
						cin >> new_player;
						if (new_player == choice)
							cout << "sorry this player has been out" << endl;
					} while (new_player != choice);
					choice = new_player;
					for (int c = 0; c < plyr; c++)
					{
						if (name[c] == choice)
						{
							peak1 = c;
							break;
						}
					}
				}
				else {
					cout << "Run is made successfully" << endl;
					int lp = 0;
					for (int z = peak1; lp < 1; lp++)
						score[z] += 1;
					count_ball += 1;
					cout << "Batsman have replaced there positions" << endl;
					choice = hint1;
					for (int c = 0; c < plyr; c++)
					{
						if (name[c] == choice)
						{
							peak1 = c;
							break;
						}
					}
				}
			}
		}
		i++;
		j++;
		show(plyr, name, score);
		if (count_ball % 6 == 0 && count_ball != 0)
		{
			ovr++;
			count_ball = 0;
		}
		cout << "your overs are ";
		cout << ovr << "." << count_ball << endl;
		if (overs == ovr || n_players < 2)
			cout << "***********innings complete.**************" << endl;
	} while (ovr != overs && n_players > 1);
	cout << "Your team score is ";             //total score
	int t_score = 0;
	for (int d = 0; d < plyr - 1; d++)
		t_score = t_score + score[d];
	cout << t_score;
}
void tossing()
{
	int overs, fact, n_players, plyr;
	string c_name, o_name, toss, choice_t, n_p;
	string name[20];
	cout << "Here is cricket designed for you." << endl;
	cout << "your circket team name: ";
	cin >> c_name;
	cout << "your opponent team name: ";
	cin >> o_name;
	cout << "no. of overs: ";
	cin >> overs;
	cout << "No. of players: ";
	cin >> n_players;
	plyr = n_players;
	//players should be greater than 2.
	do {
		if (n_players == 1 || n_players == 0)
		{
			cout << "Please enter valid number of players :";
			cin >> n_players;
		}
	} while (n_players == 1 || n_players == 0);


	cout << "AHAAA!....here is a time of tossing." << endl;
	cout << "Either you want to take head or tail? " << endl;
	cout << "TOSS: ";
	cin >> toss;
	fact = rand() % 2;
	if (fact == 0)
	{
		cout << "You have loss the toss.Now you are to do bowling.";
		cout << "************* Best of luck*************" << endl;
		batting(overs, n_players, plyr, name);
	}
	else
	{
		cout << "You have won the toss" << endl;
		cout << "ok ok. Now you are to choose....Batting or Bowling? ";
		do {
			cin >> choice_t;

			if (choice_t == "batting")
				batting(overs, n_players, plyr, name);
			else if (choice_t == "bowling")
				bowling(n_players, overs);
			else
				cout << "Enter valid option";
		} while (choice_t != "batting" && choice_t != "bowling");

	}
}

void bowling(int players, int over)
{
	int ball = over * 6;
	cout << "Here is bowling for you. ";
	cout << "There are " << over << " overs and " << ball << " balls" << endl;
	const int const_distance_v = 60;
	int entered_distance_v;
	const int const_distance_h = 70;
	int entered_distance_h;
	int const const_height = 80;
	int entered_height;
	int angle_deviation;
	string nam;
	int score = 0;
	int var = 0;
	int random;


	do {
		cout << "Vertical distance: ";
		cin >> entered_distance_v;
		cout << " Horizontal distance: ";
		cin >> entered_distance_h;
		cout << " Height: ";
		cin >> entered_height;
		cout << " Angle of deviation : ";
		cin >> angle_deviation;

		if (entered_distance_v < const_distance_v)
		{
			random = rand() % 2;
			if (random == 0)
			{
				cout << "Btasman has striked the ball" << endl;
				cout << "This is no ball" << endl;
				random = rand() % 3 + 4;
				if (random == 4)
				{
					cout << "The added scores in the case of no ball are 4. " << endl;
					score = score + 4 + 1;
					cout << "Due to no ball one score and one ball is given." << endl;
					cout << "Total score is " << score << endl;
				}

				if (random == 6)
				{
					cout << "The added scores in the case of no ball are 6." << endl;
					score = score + 6 + 1;
					cout << "Due to no ball one score and one ball is given.";
					cout << "current score is " << score << endl;
				}
			}

			else
			{
				cout << "This is no ball" << endl;
				cout << "batsman has not striked the ball" << endl;
				cout << "no score is given" << endl;
				cout << "current score is " << score << endl;


			}

		}

		else if (entered_distance_h > const_distance_h)
		{
			random = rand() % 2;
			if (random == 0)
			{
				cout << "Btasman has stricked the ball" << endl;
				cout << "There is wide ball" << endl;

				cout << "The added score in the case of wide ball are 4." << endl;
				score = score + 4 + 1;
				cout << "Due to wide ball one score is also given" << endl;
				cout << "current score is " << score << endl;
				ball--;
			}
			else
			{
				cout << "batsman have not striked the ball" << endl;
				cout << "no score is given" << endl;
				cout << "current score is " << score << endl;
				ball--;
			}

		}

		else if (entered_height > const_height)
		{
			random = rand() % 2;
			if (random == 0)
			{
				cout << "Btasman has stricked the ball" << endl;
				cout << "There is a bouncer" << endl;

				cout << "The added score in the case of wide ball are 6." << endl;
				score = score + 6 + 1;
				cout << "Due to wide ball one score is given" << endl;
				cout << "current score is " << score << endl;
				ball--;
			}
			else
			{
				cout << "batsman have not striked the ball" << endl;
				cout << "No score is given in this case" << endl;
				cout << "current score is " << score << endl;
				ball--;
			}
		}


		else if (angle_deviation > 5 || angle_deviation < -5)
		{
			random = rand() % 2;
			if (random == 0)
			{
				cout << " This was spin ball ";
				ball--;
				random = rand() % 5;
				if (random == 0)
				{
					cout << "added score in total score is 0." << endl;
					score = score + 0;
					cout << "current score is " << score << endl;
					ball--;
				}
				else if (random == 1)
				{
					cout << "added score in total score is 1." << endl;
					score = score + 1;
					cout << "Total current score is " << score << endl;
					ball--;
				}
				else if (random == 2)
				{
					cout << "added score in total score is 2." << endl;
					score = score + 2;
					cout << "current score is " << score << endl;
					ball--;
				}
				else if (random == 3)
				{
					cout << "added score in total score is 4." << endl;
					score = score + 4;
					cout << "current score is " << score << endl;
					ball--;

				}
				else if (random == 4)
				{
					cout << "added score in total score is 6." << endl;
					score = score + 6;
					cout << "current score is " << score << endl;
					ball--;
				}


			}
			else
			{
				cout << "batsman have not striked the ball" << endl;
				cout << "No score is given in this case" << endl;
				cout << "current score is " << score << endl;
				ball--;
			}

		}
		else
		{
			cout << "bowler has gone to pavilian....." << endl << endl << "***Next Bowler Entry****" << endl;
			cout << "There is no run at this ball" << endl;
			cout << "current score is " << score << endl;
			players--;
			ball--;
		}
		cout << endl << " Remaining balls are " << ball << endl;
	} while (ball > 0 && players > 0);
	cout << "***********Match has been finished**************** " << endl;
	cout << "Your total score is " << score << endl;
}